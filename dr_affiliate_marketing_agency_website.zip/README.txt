DR AFFILIATE MARKETING AGENCY — WEBSITE STARTER

This site is designed for a training/mentoring business teaching TikTok Shop affiliate marketing in the UK. It is not a product affiliate review store.

Before publishing:
- Replace the contact button URL with your real WhatsApp, TikTok profile, or enquiry form URL.
- Add your real course fee, lesson duration, contact details, privacy policy and terms.
- Confirm that claims about course length, lifetime support and results match what you actually offer.
- This is a starter website and is not yet live.

Free publishing:
1. Sign in at https://github.com
2. Create a public repository named dr-affiliate-marketing-agency
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Select Deploy from a branch, branch main, folder /(root), then Save.
6. GitHub Pages will show the published free URL when deployment completes.
